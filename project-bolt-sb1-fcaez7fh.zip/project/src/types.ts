export type TabId = 'manual' | 'simulation' | 'console';

export type FieldMode = 'rotational' | 'divergent';

export type BackendStepStatus = 'idle' | 'active' | 'done' | 'error';

export interface BackendStep {
  id: number;
  label: string;
  detail: string;
  status: BackendStepStatus;
}

export interface SimMetrics {
  divergence: number;
  curl: number;
  mode: FieldMode;
  alpha: number;
  curlIntensity: number;
}

export interface MockStats {
  apiLatency: number;
  dbRtt: number;
  tokenCost: number;
  computeTime: number;
}
