/**
 * Sandboxed code execution using a Web Worker created from a Blob.
 * Executes user-provided JS math code and captures console output + return value.
 */

export interface ExecResult {
  stdout: string[];
  error: string | null;
  returnValue: string | null;
  durationMs: number;
}

const workerTemplate = `
self.onmessage = function(e) {
  const code = e.data;
  const logs = [];
  const origLog = console.log;
  const origError = console.error;
  const origWarn = console.warn;

  const capture = (...args) => {
    logs.push(args.map(a => {
      if (typeof a === 'object') return JSON.stringify(a);
      return String(a);
    }).join(' '));
  };
  console.log = capture;
  console.error = capture;
  console.warn = capture;

  let returnValue = null;
  let error = null;

  try {
    // Provide a small math helpers context
    const sin = Math.sin, cos = Math.cos, tan = Math.tan;
    const sqrt = Math.sqrt, abs = Math.abs, pow = Math.pow;
    const PI = Math.PI, E = Math.E;
    const log = (...a) => capture(...a);

    const result = eval(code);
    if (result !== undefined) {
      returnValue = typeof result === 'object' ? JSON.stringify(result) : String(result);
    }
  } catch (err) {
    error = err.message || String(err);
  }

  console.log = origLog;
  console.error = origError;
  console.warn = origWarn;

  self.postMessage({ stdout: logs, error, returnValue });
};
`;

export function executeCode(code: string): Promise<ExecResult> {
  return new Promise((resolve) => {
    const start = performance.now();
    const blob = new Blob([workerTemplate], { type: 'application/javascript' });
    const url = URL.createObjectURL(blob);
    const worker = new Worker(url);

    const timeout = setTimeout(() => {
      worker.terminate();
      URL.revokeObjectURL(url);
      resolve({
        stdout: [],
        error: 'Execution timed out (5s limit exceeded)',
        returnValue: null,
        durationMs: performance.now() - start,
      });
    }, 5000);

    worker.onmessage = (e: MessageEvent) => {
      clearTimeout(timeout);
      worker.terminate();
      URL.revokeObjectURL(url);
      resolve({
        stdout: e.data.stdout || [],
        error: e.data.error,
        returnValue: e.data.returnValue,
        durationMs: performance.now() - start,
      });
    };

    worker.onerror = (err) => {
      clearTimeout(timeout);
      worker.terminate();
      URL.revokeObjectURL(url);
      resolve({
        stdout: [],
        error: err.message || 'Worker execution failed',
        returnValue: null,
        durationMs: performance.now() - start,
      });
    };

    worker.postMessage(code);
  });
}

/** Generates a code snippet from a user math query */
export function generateCodeFromQuery(query: string): string {
  const q = query.toLowerCase().trim();

  // Gradient
  if (q.includes('gradient') || q.includes('∇f') || q.includes('grad')) {
    const fnMatch = q.match(/f\s*=\s*(.+)/);
    const expr = fnMatch ? fnMatch[1].trim() : 'x^2 + y^2';
    return `// Gradient of f(x,y) = ${expr}
// ∇f = [∂f/∂x, ∂f/∂y]

function gradient(x, y, h = 0.001) {
  const f = (x, y) => {
    return ${expr.replace(/\^/g, '**').replace(/\bxy\b/g, 'x*y')};
  };
  const dfx = (f(x + h, y) - f(x - h, y)) / (2 * h);
  const dfy = (f(x, y + h) - f(x, y - h)) / (2 * h);
  return [dfx, dfy];
}

const [gx, gy] = gradient(2, 3);
console.log("f = ${expr}");
console.log("∇f(2, 3) = [" + gx.toFixed(4) + ", " + gy.toFixed(4) + "]");`;
  }

  // Divergence
  if (q.includes('divergence') || q.includes('div') || q.includes('∇·') || q.includes('∇.')) {
    return `// Divergence of F = [F1, F2, F3]
// ∇·F = ∂F1/∂x + ∂F2/∂y + ∂F3/∂z

function divergence(F1, F2, F3, x, y, z, h = 0.001) {
  const dF1dx = (F1(x+h,y,z) - F1(x-h,y,z)) / (2*h);
  const dF2dy = (F2(x,y+h,z) - F2(x,y-h,z)) / (2*h);
  const dF3dz = (F3(x,y,z+h) - F3(x,y,z-h)) / (2*h);
  return dF1dx + dF2dy + dF3dz;
}

// Example: F = [x², y², z²]
const F1 = (x,y,z) => x*x;
const F2 = (x,y,z) => y*y;
const F3 = (x,y,z) => z*z;

const div = divergence(F1, F2, F3, 1, 2, 3);
console.log("F = [x², y², z²]");
console.log("∇·F(1, 2, 3) = " + div.toFixed(4));`;
  }

  // Curl
  if (q.includes('curl') || q.includes('∇×') || q.includes('rotational') || q.includes('rotation')) {
    return `// Curl of F = [F1, F2, F3]
// ∇×F = [∂F3/∂y - ∂F2/∂z, ∂F1/∂z - ∂F3/∂x, ∂F2/∂x - ∂F1/∂y]

function curl(F1, F2, F3, x, y, z, h = 0.001) {
  const dF3dy = (F3(x,y+h,z) - F3(x,y-h,z)) / (2*h);
  const dF2dz = (F2(x,y,z+h) - F2(x,y,z-h)) / (2*h);
  const dF1dz = (F1(x,y,z+h) - F1(x,y,z-h)) / (2*h);
  const dF3dx = (F3(x+h,y,z) - F3(x-h,y,z)) / (2*h);
  const dF2dx = (F2(x+h,y,z) - F2(x-h,y,z)) / (2*h);
  const dF1dy = (F1(x,y+h,z) - F1(x,y-h,z)) / (2*h);
  return [dF3dy - dF2dz, dF1dz - dF3dx, dF2dx - dF1dy];
}

// Example: F = [-y, x, 0] (pure rotation)
const F1 = (x,y,z) => -y;
const F2 = (x,y,z) => x;
const F3 = (x,y,z) => 0;

const [cx, cy, cz] = curl(F1, F2, F3, 1, 1, 0);
const mag = Math.sqrt(cx*cx + cy*cy + cz*cz);
console.log("F = [-y, x, 0]");
console.log("∇×F(1, 1, 0) = [" + cx.toFixed(4) + ", " + cy.toFixed(4) + ", " + cz.toFixed(4) + "]");
console.log("|∇×F| = " + mag.toFixed(4));`;
  }

  // Octave meshgrid
  if (q.includes('meshgrid') || q.includes('octave') || q.includes('quiver')) {
    return `// Simulating GNU Octave meshgrid + quiver in JS
// F = [-y, x] (rotational field)

const N = 20;
const range = 5;

// Build meshgrid
const X = [], Y = [];
for (let i = 0; i <= N; i++) {
  X[i] = []; Y[i] = [];
  for (let j = 0; j <= N; j++) {
    X[i][j] = -range + (2 * range * j / N);
    Y[i][j] = -range + (2 * range * i / N);
  }
}

// Compute vector field F = [-y, x]
let maxMag = 0;
for (let i = 0; i <= N; i++) {
  for (let j = 0; j <= N; j++) {
    const fx = -Y[i][j];
    const fy = X[i][j];
    const mag = Math.sqrt(fx*fx + fy*fy);
    if (mag > maxMag) maxMag = mag;
  }
}

console.log("meshgrid: " + (N+1) + "x" + (N+1) + " points");
console.log("Field: F = [-y, x]");
console.log("Max |F| = " + maxMag.toFixed(4));
console.log("quiver plot ready — " + (N+1)*(N+1) + " vectors");`;
  }

  // Matrix / eigenvalue
  if (q.includes('matrix') || q.includes('eigen') || q.includes('determinant') || q.includes('det')) {
    return `// Matrix operations — determinant and trace
// A = [[a, b], [c, d]]

function det2(m) {
  return m[0][0]*m[1][1] - m[0][1]*m[1][0];
}

function trace2(m) {
  return m[0][0] + m[1][1];
}

function eigenvalues2x2(m) {
  const tr = trace2(m);
  const d = det2(m);
  const disc = Math.sqrt(tr*tr - 4*d);
  return [(tr + disc)/2, (tr - disc)/2];
}

const A = [[4, 2], [1, 3]];
console.log("A = [[4, 2], [1, 3]]");
console.log("det(A) = " + det2(A));
console.log("tr(A) = " + trace2(A));
const eigs = eigenvalues2x2(A);
console.log("Eigenvalues: λ₁ = " + eigs[0].toFixed(4) + ", λ₂ = " + eigs[1].toFixed(4));`;
  }

  // Integral
  if (q.includes('integral') || q.includes('∫') || q.includes('integrate')) {
    return `// Numerical integration using Simpson's rule
// ∫₀² x² dx

function simpson(f, a, b, n = 1000) {
  if (n % 2 !== 0) n++;
  const h = (b - a) / n;
  let sum = f(a) + f(b);
  for (let i = 1; i < n; i++) {
    sum += (i % 2 === 0 ? 2 : 4) * f(a + i * h);
  }
  return sum * h / 3;
}

const result = simpson(x => x*x, 0, 2);
console.log("∫₀² x² dx ≈ " + result.toFixed(6));
console.log("Exact = 8/3 ≈ " + (8/3).toFixed(6));`;
  }

  // Default: evaluate as math expression
  const cleaned = query
    .replace(/\^/g, '**')
    .replace(/π/g, 'Math.PI')
    .replace(/√/g, 'Math.sqrt')
    .replace(/\bsin\b/g, 'Math.sin')
    .replace(/\bcos\b/g, 'Math.cos')
    .replace(/\btan\b/g, 'Math.tan')
    .replace(/\bln\b/g, 'Math.log')
    .replace(/\blog\b/g, 'Math.log10');

  return `// Evaluating: ${query}
const result = ${cleaned};
console.log("Result: " + result);`;
}
