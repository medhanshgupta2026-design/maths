import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BookOpen, Activity, Terminal, PanelRightOpen, PanelRightClose,
  FunctionSquare, Github,
} from 'lucide-react';
import { GridBackground } from '@/components/GridBackground';
import { ManualView } from '@/components/ManualView';
import { SimulationArena } from '@/components/SimulationArena';
import { LiveConsole } from '@/components/LiveConsole';
import { BackendPanel } from '@/components/BackendPanel';
import type { TabId } from '@/types';

const tabs: { id: TabId; label: string; icon: React.ReactNode }[] = [
  { id: 'manual', label: 'Interactive Manual', icon: <BookOpen className="w-4 h-4" /> },
  { id: 'simulation', label: 'Simulation Arena', icon: <Activity className="w-4 h-4" /> },
  { id: 'console', label: 'Live Console', icon: <Terminal className="w-4 h-4" /> },
];

function App() {
  const [activeTab, setActiveTab] = useState<TabId>('simulation');
  const [backendOpen, setBackendOpen] = useState(false);
  const [backendTrigger, setBackendTrigger] = useState<string | null>(null);

  const handleAction = useCallback((action: string) => {
    // Trigger the backend panel animation with a unique value each time
    setBackendTrigger(`${action}::${Date.now()}`);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      <GridBackground />

      {/* Sticky header */}
      <header className="sticky top-0 z-40 glass-dark border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-6 h-14 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="relative w-8 h-8 flex items-center justify-center border border-emerald-500/30 rounded-sm glow-emerald">
              <FunctionSquare className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="hidden sm:block">
              <div className="text-sm font-semibold text-slate-100 tracking-tight">Vector Calculus Lab</div>
              <div className="font-mono-display text-[9px] text-slate-600 uppercase tracking-[0.2em]">GNU Octave · Live Presentation</div>
            </div>
          </div>

          {/* Tab switcher */}
          <nav className="flex items-center gap-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative flex items-center gap-2 px-3 sm:px-4 py-2 text-xs font-medium transition-colors duration-200 rounded-sm
                  ${activeTab === tab.id ? 'text-emerald-300' : 'text-slate-500 hover:text-slate-300'}`}
              >
                {tab.icon}
                <span className="hidden md:inline">{tab.label}</span>
                {activeTab === tab.id && (
                  <motion.div
                    layoutId="active-tab"
                    className="absolute inset-0 border border-emerald-500/30 bg-emerald-500/[0.06] rounded-sm -z-10"
                    transition={{ duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
                  />
                )}
              </button>
            ))}
          </nav>

          {/* Backend toggle */}
          <button
            onClick={() => setBackendOpen(o => !o)}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium border rounded-sm transition-all duration-200
              ${backendOpen
                ? 'border-cyan-500/40 text-cyan-300 bg-cyan-500/10 glow-cyan'
                : 'border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-300'}`}
          >
            {backendOpen ? <PanelRightClose className="w-3.5 h-3.5" /> : <PanelRightOpen className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">Backend</span>
          </button>
        </div>
      </header>

      {/* Main content */}
      <div className="relative flex">
        <main className={`flex-1 transition-all duration-300 ${backendOpen ? 'lg:mr-[360px]' : ''}`}>
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
            >
              {activeTab === 'manual' && <ManualView />}
              {activeTab === 'simulation' && <SimulationArena onAction={handleAction} />}
              {activeTab === 'console' && <LiveConsole onAction={handleAction} />}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Backend drawer */}
        <AnimatePresence>
          {backendOpen && (
            <>
              {/* Mobile overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setBackendOpen(false)}
                className="fixed inset-0 bg-black/40 z-30 lg:hidden"
              />
              <motion.aside
                initial={{ x: 360 }}
                animate={{ x: 0 }}
                exit={{ x: 360 }}
                transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
                className="fixed top-14 right-0 bottom-0 w-[340px] glass-dark border-l border-slate-800 z-30 overflow-y-auto"
              >
                <BackendPanel triggerAction={backendTrigger} isDrawer />
              </motion.aside>
            </>
          )}
        </AnimatePresence>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-800/50 py-4 px-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-[10px] font-mono-display text-slate-700">
          <span>Vector Calculus Lab · φ-spaced grid system · 4px baseline</span>
          <span className="flex items-center gap-1.5">
            <Github className="w-3 h-3" />
            <span>Octave/MATLAB compatible</span>
          </span>
        </div>
      </footer>
    </div>
  );
}

export default App;
