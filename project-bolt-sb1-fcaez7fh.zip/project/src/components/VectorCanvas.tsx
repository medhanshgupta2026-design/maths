import { useRef, useEffect, useCallback } from 'react';
import type { FieldMode } from '@/types';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  trail: { x: number; y: number }[];
  life: number;
}

interface VectorCanvasProps {
  mode: FieldMode;
  alpha: number;
  curlIntensity: number;
  onMetrics?: (divergence: number, curl: number) => void;
  resetSignal?: number;
}

const PARTICLE_COUNT = 400;
const TRAIL_LENGTH = 8;
const MAX_SPEED = 4;

export function VectorCanvas({ mode, alpha, curlIntensity, onMetrics, resetSignal }: VectorCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const animFrameRef = useRef<number>(0);
  const paramsRef = useRef({ mode, alpha, curlIntensity });
  const mouseRef = useRef<{ x: number; y: number; active: boolean }>({ x: 0, y: 0, active: false });

  // Keep latest params without restarting the animation loop
  useEffect(() => {
    paramsRef.current = { mode, alpha, curlIntensity };
  }, [mode, alpha, curlIntensity]);

  const getVelocity = useCallback((x: number, y: number, cx: number, cy: number): [number, number] => {
    const dx = x - cx;
    const dy = y - cy;
    const { mode: m, alpha: a, curlIntensity: c } = paramsRef.current;

    if (m === 'rotational') {
      // F = [-y, x] modified by curl factor
      const fx = -dy * c;
      const fy = dx * c;
      return [fx, fy];
    } else {
      // F = [x, y] modified by alpha (radial outward/inward)
      const fx = dx * a * 0.02;
      const fy = dy * a * 0.02;
      return [fx, fy];
    }
  }, []);

  const seedParticles = useCallback((w: number, h: number, count = PARTICLE_COUNT) => {
    const particles: Particle[] = [];
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: 0,
        vy: 0,
        trail: [],
        life: Math.random() * 200 + 100,
      });
    }
    particlesRef.current = particles;
  }, []);

  // Main animation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let w = canvas.width = canvas.offsetWidth;
    let h = canvas.height = canvas.offsetHeight;

    const resizeObserver = new ResizeObserver(() => {
      w = canvas.width = canvas.offsetWidth;
      h = canvas.height = canvas.offsetHeight;
      seedParticles(w, h);
    });
    resizeObserver.observe(canvas);

    seedParticles(w, h);

    let lastMetricsUpdate = 0;

    const render = (time: number) => {
      const { mode: m, alpha: a, curlIntensity: c } = paramsRef.current;
      const cx = w / 2;
      const cy = h / 2;

      // Semi-transparent clear for trail effect
      ctx.fillStyle = 'rgba(2, 6, 23, 0.12)';
      ctx.fillRect(0, 0, w, h);

      // Draw subtle grid
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.04)';
      ctx.lineWidth = 0.5;
      const gridStep = 40;
      ctx.beginPath();
      for (let x = 0; x <= w; x += gridStep) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
      }
      for (let y = 0; y <= h; y += gridStep) {
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
      }
      ctx.stroke();

      // Draw center crosshair
      ctx.strokeStyle = 'rgba(34, 211, 238, 0.15)';
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.moveTo(cx - 12, cy);
      ctx.lineTo(cx + 12, cy);
      ctx.moveTo(cx, cy - 12);
      ctx.lineTo(cx, cy + 12);
      ctx.stroke();

      const particles = particlesRef.current;
      const accentColor = m === 'rotational' ? '16, 185, 129' : '34, 211, 238';

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Mouse interaction — re-seed nearby particles
        if (mouseRef.current.active) {
          const mdx = p.x - mouseRef.current.x;
          const mdy = p.y - mouseRef.current.y;
          const mdist = Math.sqrt(mdx * mdx + mdy * mdy);
          if (mdist < 80) {
            p.x = mouseRef.current.x + (Math.random() - 0.5) * 120;
            p.y = mouseRef.current.y + (Math.random() - 0.5) * 120;
            p.trail = [];
            p.life = Math.random() * 200 + 100;
          }
        }

        const [vx, vy] = getVelocity(p.x, p.y, cx, cy);
        p.vx = p.vx * 0.9 + vx * 0.1;
        p.vy = p.vy * 0.9 + vy * 0.1;

        // Clamp speed
        const speed = Math.sqrt(p.vx * p.vx + p.vy * p.vy);
        if (speed > MAX_SPEED) {
          p.vx = (p.vx / speed) * MAX_SPEED;
          p.vy = (p.vy / speed) * MAX_SPEED;
        }

        p.x += p.vx;
        p.y += p.vy;
        p.life--;

        // Update trail
        p.trail.push({ x: p.x, y: p.y });
        if (p.trail.length > TRAIL_LENGTH) p.trail.shift();

        // Draw trail
        if (p.trail.length > 1) {
          for (let t = 0; t < p.trail.length - 1; t++) {
            const alpha = (t / p.trail.length) * 0.6;
            ctx.strokeStyle = `rgba(${accentColor}, ${alpha})`;
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            ctx.moveTo(p.trail[t].x, p.trail[t].y);
            ctx.lineTo(p.trail[t + 1].x, p.trail[t + 1].y);
            ctx.stroke();
          }
        }

        // Draw particle head
        ctx.fillStyle = `rgba(${accentColor}, 0.8)`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 1.5, 0, Math.PI * 2);
        ctx.fill();

        // Respawn if out of bounds or dead
        if (p.x < -20 || p.x > w + 20 || p.y < -20 || p.y > h + 20 || p.life <= 0) {
          p.x = Math.random() * w;
          p.y = Math.random() * h;
          p.vx = 0;
          p.vy = 0;
          p.trail = [];
          p.life = Math.random() * 200 + 100;
        }
      }

      // Update metrics ~4 times per second
      if (time - lastMetricsUpdate > 250 && onMetrics) {
        lastMetricsUpdate = time;
        if (m === 'divergent') {
          onMetrics(a, 0);
        } else {
          onMetrics(0, c);
        }
      }

      animFrameRef.current = requestAnimationFrame(render);
    };

    animFrameRef.current = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animFrameRef.current);
      resizeObserver.disconnect();
    };
  }, [seedParticles, getVelocity, onMetrics]);

  // Reset particles when resetSignal changes
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    seedParticles(canvas.width, canvas.height);
  }, [resetSignal, seedParticles]);

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    mouseRef.current.active = true;
    const rect = e.currentTarget.getBoundingClientRect();
    mouseRef.current.x = e.clientX - rect.left;
    mouseRef.current.y = e.clientY - rect.top;
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!mouseRef.current.active) return;
    const rect = e.currentTarget.getBoundingClientRect();
    mouseRef.current.x = e.clientX - rect.left;
    mouseRef.current.y = e.clientY - rect.top;
  };

  const handlePointerUp = () => {
    mouseRef.current.active = false;
  };

  return (
    <canvas
      ref={canvasRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerUp}
      className="w-full h-full block cursor-crosshair touch-none"
      style={{ background: '#020617' }}
    />
  );
}
