import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Server, ArrowRight, ShieldCheck, Database, Lock, Cpu,
  Activity, Timer, DollarSign, Zap,
} from 'lucide-react';
import { CornerBrackets } from '@/components/GridBackground';
import type { BackendStep, MockStats } from '@/types';

const baseSteps: Omit<BackendStep, 'status'>[] = [
  { id: 1, label: 'User Request', detail: 'Input received from client UI' },
  { id: 2, label: 'JWT Auth Verification', detail: 'Token validated · session confirmed' },
  { id: 3, label: 'Database Query Optimization', detail: 'Indexed lookup · prepared statement' },
  { id: 4, label: 'Encrypted API Response', detail: 'TLS 1.3 · JSON payload sealed' },
];

interface BackendPanelProps {
  triggerAction: string | null;
  isDrawer: boolean;
}

export function BackendPanel({ triggerAction, isDrawer }: BackendPanelProps) {
  const [steps, setSteps] = useState<BackendStep[]>(
    baseSteps.map(s => ({ ...s, status: 'idle' as const }))
  );
  const [stats, setStats] = useState<MockStats>({
    apiLatency: 42,
    dbRtt: 12,
    tokenCost: 0.0002,
    computeTime: 3.2,
  });
  const [highlightedStep, setHighlightedStep] = useState<number | null>(null);
  const timeoutsRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  // Clear timeouts on unmount
  useEffect(() => {
    return () => {
      timeoutsRef.current.forEach(clearTimeout);
    };
  }, []);

  // Animate the flow when an action is triggered
  useEffect(() => {
    if (!triggerAction) return;

    // Reset all steps
    setSteps(baseSteps.map(s => ({ ...s, status: 'idle' })));

    // Clear previous timeouts
    timeoutsRef.current.forEach(clearTimeout);
    timeoutsRef.current = [];

    // Animate each step sequentially
    baseSteps.forEach((step, index) => {
      const activateTime = index * 400;
      const doneTime = (index + 1) * 400;

      const t1 = setTimeout(() => {
        setSteps(prev => prev.map(s => s.id === step.id ? { ...s, status: 'active' } : s));
        setHighlightedStep(step.id);
      }, activateTime);
      timeoutsRef.current.push(t1);

      const t2 = setTimeout(() => {
        setSteps(prev => prev.map(s => s.id === step.id ? { ...s, status: 'done' } : s));
      }, doneTime);
      timeoutsRef.current.push(t2);
    });

    // Update mock stats with slight variation
    const t3 = setTimeout(() => {
      setStats({
        apiLatency: 35 + Math.random() * 20,
        dbRtt: 8 + Math.random() * 12,
        tokenCost: 0.0001 + Math.random() * 0.0003,
        computeTime: 2 + Math.random() * 4,
      });
    }, 200);
    timeoutsRef.current.push(t3);

    const t4 = setTimeout(() => setHighlightedStep(null), baseSteps.length * 400 + 200);
    timeoutsRef.current.push(t4);
  }, [triggerAction]);

  const stepIcons = [
    <Server className="w-3.5 h-3.5" />,
    <ShieldCheck className="w-3.5 h-3.5" />,
    <Database className="w-3.5 h-3.5" />,
    <Lock className="w-3.5 h-3.5" />,
  ];

  const containerClass = isDrawer
    ? "h-full"
    : "glass-dark border border-slate-800 rounded-sm";

  return (
    <div className={`${containerClass} p-5 space-y-5`}>
      {/* Header */}
      <div className="flex items-center gap-2">
        <Cpu className="w-4 h-4 text-cyan-400" />
        <h3 className="font-mono-display text-xs uppercase tracking-[0.2em] text-slate-300">
          How the Backend Works
        </h3>
      </div>

      {/* Flow diagram */}
      <div className="space-y-0">
        {steps.map((step, index) => (
          <div key={step.id}>
            <motion.div
              animate={{
                backgroundColor: step.status === 'active' ? 'rgba(34, 211, 238, 0.06)' : 'rgba(15, 23, 42, 0)',
                borderColor: step.status === 'active' ? 'rgba(34, 211, 238, 0.4)' : step.status === 'done' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(30, 41, 59, 0.8)',
              }}
              transition={{ duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
              className="relative flex items-center gap-3 px-4 py-3 border rounded-sm"
            >
              {/* Step number */}
              <div className={`shrink-0 w-6 h-6 flex items-center justify-center font-mono-display text-[10px] border rounded-sm transition-colors duration-200
                ${step.status === 'active' ? 'border-cyan-500/50 text-cyan-400 bg-cyan-500/10'
                  : step.status === 'done' ? 'border-emerald-500/40 text-emerald-400 bg-emerald-500/5'
                  : 'border-slate-700 text-slate-600'}`}
              >
                {step.id}
              </div>

              {/* Icon */}
              <div className={`shrink-0 ${step.status === 'active' ? 'text-cyan-400' : step.status === 'done' ? 'text-emerald-400' : 'text-slate-600'}`}>
                {stepIcons[index]}
              </div>

              {/* Text */}
              <div className="min-w-0">
                <div className={`text-xs font-medium transition-colors duration-200
                  ${step.status === 'active' ? 'text-cyan-300' : step.status === 'done' ? 'text-slate-200' : 'text-slate-500'}`}
                >
                  {step.label}
                </div>
                <div className="text-[10px] text-slate-600 truncate">{step.detail}</div>
              </div>

              {/* Status indicator */}
              {step.status === 'active' && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="ml-auto shrink-0"
                >
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                </motion.div>
              )}
              {step.status === 'done' && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="ml-auto shrink-0 text-emerald-400"
                >
                  <svg className="w-3 h-3" viewBox="0 0 12 12" fill="none">
                    <path d="M2 6L5 9L10 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </motion.div>
              )}
            </motion.div>

            {/* Connector line */}
            {index < steps.length - 1 && (
              <div className="flex justify-start pl-[2.15rem] py-0.5">
                <div className={`w-px h-4 transition-colors duration-200 ${step.status === 'done' ? 'bg-emerald-500/30' : 'bg-slate-800'}`} />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Real-time stats */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 mb-1">
          <Activity className="w-3 h-3 text-slate-500" />
          <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-slate-500">Real-time Metrics</span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <StatWidget
            icon={<Timer className="w-3 h-3" />}
            label="API Latency"
            value={`${stats.apiLatency.toFixed(0)}ms`}
            color="cyan"
          />
          <StatWidget
            icon={<Database className="w-3 h-3" />}
            label="DB RTT"
            value={`${stats.dbRtt.toFixed(0)}ms`}
            color="emerald"
          />
          <StatWidget
            icon={<Zap className="w-3 h-3" />}
            label="Compute"
            value={`${stats.computeTime.toFixed(1)}ms`}
            color="cyan"
          />
          <StatWidget
            icon={<DollarSign className="w-3 h-3" />}
            label="Token Cost"
            value={`$${stats.tokenCost.toFixed(5)}`}
            color="emerald"
          />
        </div>
      </div>
    </div>
  );
}

function StatWidget({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: string; color: 'cyan' | 'emerald' }) {
  const c = color === 'cyan' ? 'text-cyan-400' : 'text-emerald-400';
  return (
    <div className="relative glass border border-slate-800 p-3 rounded-sm">
      <CornerBrackets color={color} />
      <div className="flex items-center gap-1.5 mb-1">
        <span className={c}>{icon}</span>
        <span className="font-mono-display text-[9px] uppercase tracking-wider text-slate-500">{label}</span>
      </div>
      <div className={`font-mono-display text-sm tabular-nums ${c}`}>{value}</div>
    </div>
  );
}
