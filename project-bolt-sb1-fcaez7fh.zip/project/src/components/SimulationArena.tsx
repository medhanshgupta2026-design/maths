import { useState, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  RotateCw, Expand, Zap, Gauge, Activity, AlertTriangle, CheckCircle2,
  Target, Sliders, RefreshCw, MousePointerClick,
} from 'lucide-react';
import { VectorCanvas } from '@/components/VectorCanvas';
import { CornerBrackets } from '@/components/GridBackground';
import type { FieldMode } from '@/types';

interface SimulationArenaProps {
  onAction: (action: string) => void;
}

interface Preset {
  name: string;
  mode: FieldMode;
  curl: number;
  alpha: number;
  icon: React.ReactNode;
  desc: string;
}

const presets: Preset[] = [
  { name: 'Pure Rotation', mode: 'rotational', curl: 2.0, alpha: 1.0, icon: <RotateCw className="w-4 h-4" />, desc: 'Curl Max — rotational field at maximum angular velocity' },
  { name: 'Pure Divergence', mode: 'divergent', curl: 0, alpha: 2.0, icon: <Expand className="w-4 h-4" />, desc: 'Sink/Source — radial outward expansion at full scale' },
  { name: 'Chaos Storm', mode: 'rotational', curl: -1.8, alpha: 2.5, icon: <Zap className="w-4 h-4" />, desc: 'Reversed rotation at high velocity — critical breakout' },
];

export function SimulationArena({ onAction }: SimulationArenaProps) {
  const [mode, setMode] = useState<FieldMode>('rotational');
  const [alpha, setAlpha] = useState(1.0);
  const [curlIntensity, setCurlIntensity] = useState(1.0);
  const [resetSignal, setResetSignal] = useState(0);
  const [metrics, setMetrics] = useState({ divergence: 0, curl: 1.0 });

  const handleMetrics = useCallback((divergence: number, curl: number) => {
    setMetrics({ divergence, curl });
  }, []);

  const applyPreset = (preset: Preset) => {
    setMode(preset.mode);
    setCurlIntensity(preset.curl);
    setAlpha(preset.alpha);
    onAction(`Preset: ${preset.name}`);
  };

  const isCritical = Math.abs(curlIntensity) > 1.4;

  const presetButtons = useMemo(() => presets.map((p, i) => {
    const isActive = mode === p.mode && curlIntensity === p.curl && alpha === p.alpha;
    return (
      <motion.button
        key={p.name}
        initial={{ opacity: 0, x: -8 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: i * 0.05, ease: [0.4, 0, 0.2, 1] }}
        onClick={() => applyPreset(p)}
        className={`group relative w-full text-left px-4 py-3 border transition-all duration-150 rounded-sm
          ${isActive
            ? 'border-emerald-500/40 bg-emerald-500/[0.06] glow-emerald'
            : 'border-slate-800 bg-slate-900/30 hover:border-slate-700 hover:bg-slate-800/30'
          }`}
      >
        <div className="flex items-center gap-2 mb-1">
          <span className={isActive ? 'text-emerald-400' : 'text-slate-400'}>{p.icon}</span>
          <span className={`text-xs font-medium ${isActive ? 'text-emerald-300' : 'text-slate-300'}`}>
            {p.name}
          </span>
        </div>
        <p className="text-[10px] text-slate-500 leading-tight">{p.desc}</p>
        {isActive && (
          <div className="absolute top-2 right-2">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          </div>
        )}
      </motion.button>
    );
  }), [mode, curlIntensity, alpha, onAction]);

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-6 space-y-1"
      >
        <div className="flex items-center gap-2 text-cyan-400 font-mono-display text-xs uppercase tracking-[0.3em]">
          <Activity className="w-3.5 h-3.5" />
          <span>Simulation Arena</span>
        </div>
        <h1 className="text-3xl font-semibold text-slate-100 tracking-tight">
          Vector Field <span className="text-cyan-400">Particle Tracker</span>
        </h1>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-6">
        {/* Canvas + metrics */}
        <div className="space-y-4">
          {/* Canvas */}
          <div className="relative glass-dark border border-slate-800 rounded-sm overflow-hidden" style={{ aspectRatio: '1.618 / 1' }}>
            <CornerBrackets color="cyan" />
            <VectorCanvas
              mode={mode}
              alpha={alpha}
              curlIntensity={curlIntensity}
              onMetrics={handleMetrics}
              resetSignal={resetSignal}
            />
            {/* Canvas overlay info */}
            <div className="absolute top-3 left-3 flex items-center gap-2 pointer-events-none">
              <div className={`px-2 py-1 font-mono-display text-[10px] uppercase tracking-wider border rounded-sm
                ${mode === 'rotational' ? 'border-emerald-500/30 text-emerald-400 bg-emerald-500/5' : 'border-cyan-500/30 text-cyan-400 bg-cyan-500/5'}`}
              >
                {mode === 'rotational' ? 'F = [-y, x]' : 'F = [x, y]'}
              </div>
              <div className="px-2 py-1 font-mono-display text-[10px] uppercase tracking-wider text-slate-500 border border-slate-800 rounded-sm bg-slate-950/50">
                400 particles · 60fps
              </div>
            </div>
            <div className="absolute bottom-3 right-3 flex items-center gap-1.5 pointer-events-none">
              <MousePointerClick className="w-3 h-3 text-slate-600" />
              <span className="font-mono-display text-[10px] text-slate-600">click/drag to warp</span>
            </div>
          </div>

          {/* Live metrics row */}
          <div className="grid grid-cols-2 gap-4">
            {/* Divergence */}
            <div className="relative glass border border-slate-800 p-4 rounded-sm">
              <CornerBrackets color="cyan" />
              <div className="flex items-center gap-2 mb-2">
                <Expand className="w-3.5 h-3.5 text-cyan-400" />
                <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-slate-400">Divergence ∇·F</span>
              </div>
              <div className="font-mono-display text-2xl text-cyan-400 text-glow-cyan tabular-nums">
                {metrics.divergence.toFixed(3)}
              </div>
              <div className="font-mono-display text-[10px] text-slate-600 mt-1">
                {mode === 'divergent' ? 'α = ' + alpha.toFixed(2) : 'inactive (rotational mode)'}
              </div>
            </div>

            {/* Curl */}
            <div className="relative glass border border-slate-800 p-4 rounded-sm">
              <CornerBrackets color="emerald" />
              <div className="flex items-center gap-2 mb-2">
                <RotateCw className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-slate-400">Curl |∇×F|</span>
              </div>
              <div className="font-mono-display text-2xl text-emerald-400 text-glow-emerald tabular-nums">
                {metrics.curl.toFixed(3)}
              </div>
              <div className="font-mono-display text-[10px] text-slate-600 mt-1">
                {mode === 'rotational' ? 'ω = ' + curlIntensity.toFixed(2) : 'inactive (divergent mode)'}
              </div>
            </div>
          </div>

          {/* System Status + Challenge */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* System status */}
            <div className={`relative glass border p-4 rounded-sm transition-all duration-200
              ${isCritical ? 'border-red-500/40 bg-red-500/[0.04]' : 'border-emerald-500/30 bg-emerald-500/[0.03]'}`}
            >
              <div className="flex items-center gap-2 mb-2">
                {isCritical ? <AlertTriangle className="w-4 h-4 text-red-400" /> : <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-slate-400">System Status</span>
              </div>
              <AnimatePresence mode="wait">
                {isCritical ? (
                  <motion.div
                    key="critical"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="font-mono-display text-base text-red-400 animate-blink"
                  >
                    CRITICAL VELOCITY BREAKOUT
                  </motion.div>
                ) : (
                  <motion.div
                    key="stable"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="font-mono-display text-base text-emerald-400 text-glow-emerald"
                  >
                    GRID STABLE
                  </motion.div>
                )}
              </AnimatePresence>
              <div className="font-mono-display text-[10px] text-slate-600 mt-1">
                |curl| = {Math.abs(curlIntensity).toFixed(2)} {isCritical ? '> 1.4 threshold' : '≤ 1.4 threshold'}
              </div>
            </div>

            {/* Audience challenge */}
            <div className="relative glass border border-amber-500/20 bg-amber-500/[0.03] p-4 rounded-sm">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-amber-400" />
                <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-amber-400">Professor / Audience Challenge</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed mb-2">
                Can you balance the vectors?
              </p>
              <p className="text-xs text-amber-300/90 leading-relaxed font-medium">
                Task: Adjust the Curl Intensity Matrix slider to exactly 0.0 to stabilize the system.
              </p>
              <div className="mt-2 font-mono-display text-[10px] text-slate-600">
                Current: {curlIntensity.toFixed(2)} {curlIntensity === 0 ? '✓ BALANCED' : ''}
              </div>
            </div>
          </div>
        </div>

        {/* Control sidebar */}
        <div className="space-y-4">
          {/* Mode selectors */}
          <div className="glass border border-slate-800 p-5 rounded-sm space-y-3">
            <div className="flex items-center gap-2 mb-1">
              <Sliders className="w-3.5 h-3.5 text-slate-400" />
              <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-slate-400">Vector Topology</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => { setMode('rotational'); onAction('Mode: Rotational'); }}
                className={`px-3 py-2.5 text-xs font-medium border rounded-sm transition-all duration-150
                  ${mode === 'rotational'
                    ? 'border-emerald-500/40 bg-emerald-500/[0.08] text-emerald-300 glow-emerald'
                    : 'border-slate-800 bg-slate-900/30 text-slate-400 hover:border-slate-700 hover:text-slate-300'
                  }`}
              >
                <RotateCw className="w-3.5 h-3.5 inline mr-1.5" />
                Rotational
              </button>
              <button
                onClick={() => { setMode('divergent'); onAction('Mode: Divergent'); }}
                className={`px-3 py-2.5 text-xs font-medium border rounded-sm transition-all duration-150
                  ${mode === 'divergent'
                    ? 'border-cyan-500/40 bg-cyan-500/[0.08] text-cyan-300 glow-cyan'
                    : 'border-slate-800 bg-slate-900/30 text-slate-400 hover:border-slate-700 hover:text-slate-300'
                  }`}
              >
                <Expand className="w-3.5 h-3.5 inline mr-1.5" />
                Divergent
              </button>
            </div>
          </div>

          {/* Sliders */}
          <div className="glass border border-slate-800 p-5 rounded-sm space-y-5">
            <div className="flex items-center gap-2 mb-1">
              <Gauge className="w-3.5 h-3.5 text-slate-400" />
              <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-slate-400">Parameters</span>
            </div>

            {/* Alpha slider */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs text-slate-300">Velocity Alpha <span className="text-slate-600">α</span></label>
                <span className="font-mono-display text-xs text-emerald-400 tabular-nums">{alpha.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min={0.2}
                max={2.5}
                step={0.05}
                value={alpha}
                onChange={(e) => setAlpha(parseFloat(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between font-mono-display text-[9px] text-slate-700">
                <span>0.2</span><span>2.5</span>
              </div>
            </div>

            {/* Curl slider */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs text-slate-300">Curl Intensity <span className="text-slate-600">ω</span></label>
                <span className={`font-mono-display text-xs tabular-nums ${isCritical ? 'text-red-400' : 'text-cyan-400'}`}>
                  {curlIntensity.toFixed(2)}
                </span>
              </div>
              <input
                type="range"
                min={-2.0}
                max={2.0}
                step={0.05}
                value={curlIntensity}
                onChange={(e) => setCurlIntensity(parseFloat(e.target.value))}
                className={`w-full ${isCritical ? '' : 'slider-cyan'}`}
              />
              <div className="flex justify-between font-mono-display text-[9px] text-slate-700">
                <span>-2.0</span><span>0.0</span><span>2.0</span>
              </div>
            </div>

            {/* Reset button */}
            <button
              onClick={() => { setResetSignal(s => s + 1); onAction('Reset Particles'); }}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium border border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-300 hover:bg-slate-800/30 rounded-sm transition-all duration-150"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Re-seed Particles
            </button>
          </div>

          {/* Presentation presets */}
          <div className="glass border border-slate-800 p-5 rounded-sm space-y-3">
            <div className="flex items-center gap-2 mb-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-amber-400">Presentation Presets</span>
            </div>
            <div className="space-y-2">
              {presetButtons}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
