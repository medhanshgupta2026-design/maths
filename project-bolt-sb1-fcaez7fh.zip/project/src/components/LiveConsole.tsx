import { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Terminal, Play, Square, Loader2, ChevronRight, Code2,
  CheckCircle2, XCircle, Sparkles,
} from 'lucide-react';
import { CornerBrackets } from '@/components/GridBackground';
import { executeCode, generateCodeFromQuery, type ExecResult } from '@/utils/sandbox';
import type { BackendStep } from '@/types';

interface LiveConsoleProps {
  onAction: (action: string) => void;
  onBackendStep?: (stepIndex: number) => void;
}

const exampleQueries = [
  'gradient of f = x^2 + y^2',
  'curl of F = [-y, x, 0]',
  'divergence of F = [x^2, y^2, z^2]',
  'meshgrid quiver octave',
  'eigenvalues of [[4,2],[1,3]]',
  'integral of x^2 from 0 to 2',
];

const backendFlowLabels = [
  'User Input',
  'Executing Sandboxed Web Worker',
  'Printing Isolated Output String',
];

export function LiveConsole({ onAction, onBackendStep }: LiveConsoleProps) {
  const [query, setQuery] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [streamedCode, setStreamedCode] = useState('');
  const [output, setOutput] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [executed, setExecuted] = useState(false);
  const [execDuration, setExecDuration] = useState<number | null>(null);
  const streamTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const stopStream = () => {
    if (streamTimerRef.current) {
      clearInterval(streamTimerRef.current);
      streamTimerRef.current = null;
    }
  };

  const runCode = useCallback(async (code: string) => {
    setIsRunning(true);
    setOutput([]);
    setError(null);
    setExecuted(false);

    // Highlight backend steps
    onBackendStep?.(0); // User Input

    const result: ExecResult = await executeCode(code);

    onBackendStep?.(1); // Executing Web Worker

    // Small delay for visual effect
    await new Promise(r => setTimeout(r, 200));

    if (result.error) {
      // Format error nicely
      const lineMatch = result.error.match(/line (\d+)/i);
      const errorLine = lineMatch ? ` at line ${lineMatch[1]}` : '';
      setError(`Runtime Error: ${result.error}${errorLine}`);
      setOutput([]);
    } else {
      setOutput(result.stdout.length > 0 ? result.stdout : ['(no output)']);
    }

    setExecDuration(result.durationMs);
    setExecuted(true);
    setIsRunning(false);

    onBackendStep?.(2); // Printing Output
    onAction('Code Executed');
  }, [onAction, onBackendStep]);

  const handleSubmit = async () => {
    const q = query.trim();
    if (!q || isRunning || isStreaming) return;

    stopStream();
    setOutput([]);
    setError(null);
    setExecuted(false);
    setExecDuration(null);
    setStreamedCode('');

    const code = generateCodeFromQuery(q);
    setGeneratedCode(code);
    onAction(`Query: ${q}`);

    // Stream the code character by character
    setIsStreaming(true);
    let charIndex = 0;
    const streamSpeed = Math.max(1, Math.min(3, Math.ceil(code.length / 200)));

    streamTimerRef.current = setInterval(() => {
      if (charIndex >= code.length) {
        stopStream();
        setIsStreaming(false);
        runCode(code);
        return;
      }
      charIndex += streamSpeed;
      setStreamedCode(code.slice(0, charIndex));
    }, 12);
  };

  const handleStop = () => {
    stopStream();
    setIsStreaming(false);
    setIsRunning(false);
  };

  const handleExampleClick = (example: string) => {
    setQuery(example);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="space-y-1"
      >
        <div className="flex items-center gap-2 text-emerald-400 font-mono-display text-xs uppercase tracking-[0.3em]">
          <Code2 className="w-3.5 h-3.5" />
          <span>Live Coding Environment</span>
        </div>
        <h1 className="text-3xl font-semibold text-slate-100 tracking-tight">
          Octave-Style <span className="text-emerald-400">Execution Console</span>
        </h1>
        <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
          Type a mathematical query or coding question. The system generates executable code, streams it into the editor,
          and runs it in a sandboxed Web Worker — printing results in real-time.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
        {/* Main terminal area */}
        <div className="space-y-4">
          {/* Input prompt */}
          <div className="relative glass-dark border border-slate-800 rounded-sm overflow-hidden">
            <CornerBrackets color="emerald" />
            <div className="flex items-center gap-2 px-4 py-2.5 border-b border-slate-800">
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-slate-400">Command Prompt</span>
            </div>
            <div className="flex items-stretch">
              <div className="flex items-center px-4 py-3 font-mono-display text-sm text-emerald-400 text-glow-emerald select-none">
                &gt;&gt;
              </div>
              <textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSubmit();
                  }
                }}
                placeholder="e.g. gradient of f = x^2 + y^2  —  press Enter to run"
                rows={1}
                disabled={isRunning || isStreaming}
                className="flex-1 bg-transparent text-slate-200 font-mono-display text-sm py-3 pr-3 outline-none resize-none placeholder:text-slate-700 disabled:opacity-50"
              />
              <div className="flex items-center pr-3">
                {isRunning || isStreaming ? (
                  <button
                    onClick={handleStop}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-red-500/30 text-red-400 hover:bg-red-500/10 rounded-sm transition-colors duration-150"
                  >
                    <Square className="w-3 h-3" />
                    Stop
                  </button>
                ) : (
                  <button
                    onClick={handleSubmit}
                    disabled={!query.trim()}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-emerald-500/40 text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 glow-emerald rounded-sm transition-all duration-150 disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:bg-emerald-500/10"
                  >
                    <Play className="w-3 h-3" />
                    Run
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Generated code editor */}
          <div className="relative glass-dark border border-slate-800 rounded-sm overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Code2 className="w-3.5 h-3.5 text-cyan-400" />
                <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-slate-400">
                  Generated Code
                </span>
                {isStreaming && (
                  <span className="flex items-center gap-1 text-[10px] text-cyan-400 font-mono-display">
                    <Loader2 className="w-3 h-3 animate-spin" />
                    streaming
                  </span>
                )}
              </div>
              {executed && !error && (
                <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-mono-display">
                  <CheckCircle2 className="w-3 h-3" />
                  executed · {execDuration?.toFixed(0)}ms
                </span>
              )}
            </div>
            <div className="bg-[#020617] min-h-[200px] max-h-[400px] overflow-auto">
              {streamedCode ? (
                <pre className="font-mono-display text-[13px] leading-[1.7] p-4">
                  <code className="text-slate-200">{streamedCode}</code>
                  {isStreaming && <span className="terminal-cursor" />}
                </pre>
              ) : (
                <div className="p-4 text-slate-700 font-mono-display text-[13px]">
                  // Generated code will appear here after you press Run
                </div>
              )}
            </div>
          </div>

          {/* Terminal output */}
          <div className="relative glass-dark border border-slate-800 rounded-sm overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-slate-400">
                  Terminal Output
                </span>
              </div>
              {isRunning && (
                <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-mono-display">
                  <Loader2 className="w-3 h-3 animate-spin" />
                  executing
                </span>
              )}
            </div>
            <div className="bg-[#020617] min-h-[120px] max-h-[300px] overflow-auto p-4">
              <AnimatePresence mode="wait">
                {error ? (
                  <motion.div
                    key="error"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-1"
                  >
                    <div className="flex items-center gap-2 text-red-400 font-mono-display text-sm">
                      <XCircle className="w-4 h-4" />
                      <span>{error}</span>
                    </div>
                  </motion.div>
                ) : output.length > 0 ? (
                  <motion.div
                    key="output"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-0.5"
                  >
                    {output.map((line, i) => (
                      <div key={i} className="font-mono-display text-[13px] leading-[1.6] text-[#22C55E]">
                        <span className="text-slate-700 select-none">{'>'} </span>
                        {line}
                      </div>
                    ))}
                  </motion.div>
                ) : !isRunning ? (
                  <div className="text-slate-700 font-mono-display text-[13px]">
                    $ awaiting execution...
                  </div>
                ) : null}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Sidebar: examples + backend flow */}
        <div className="space-y-4">
          {/* Example queries */}
          <div className="glass border border-slate-800 p-5 rounded-sm space-y-3">
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-amber-400">Example Queries</span>
            </div>
            <div className="space-y-1.5">
              {exampleQueries.map((ex, i) => (
                <button
                  key={i}
                  onClick={() => handleExampleClick(ex)}
                  disabled={isRunning || isStreaming}
                  className="group w-full flex items-center gap-2 px-3 py-2 text-left text-xs text-slate-400 border border-slate-800 hover:border-slate-700 hover:text-slate-200 hover:bg-slate-800/30 rounded-sm transition-all duration-150 disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  <ChevronRight className="w-3 h-3 text-slate-600 group-hover:text-emerald-400 transition-colors" />
                  <span className="font-mono-display truncate">{ex}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Backend flow mini-view */}
          <BackendFlowMini onBackendStep={onBackendStep} />
        </div>
      </div>
    </div>
  );
}

function BackendFlowMini({ onBackendStep }: { onBackendStep?: (step: number) => void }) {
  const [activeStep, setActiveStep] = useState<number | null>(null);

  // Listen for backend step triggers via a polling approach
  // This is a simplified visual that mirrors the main backend panel
  const steps = backendFlowLabels;

  return (
    <div className="glass border border-slate-800 p-5 rounded-sm space-y-3">
      <div className="flex items-center gap-2 mb-1">
        <Terminal className="w-3.5 h-3.5 text-cyan-400" />
        <span className="font-mono-display text-[10px] uppercase tracking-[0.2em] text-cyan-400">Execution Pipeline</span>
      </div>
      <div className="space-y-0">
        {steps.map((label, index) => (
          <div key={index}>
            <div className="flex items-center gap-2 py-2 px-2 border border-slate-800/50 rounded-sm">
              <div className={`w-4 h-4 flex items-center justify-center font-mono-display text-[8px] border rounded-sm transition-colors
                ${activeStep === index ? 'border-cyan-500/50 text-cyan-400 bg-cyan-500/10' : 'border-slate-700 text-slate-600'}`}
              >
                {index + 1}
              </div>
              <span className={`text-[10px] leading-tight transition-colors ${activeStep === index ? 'text-cyan-300' : 'text-slate-500'}`}>
                {label}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div className="flex justify-start pl-[1.4rem]">
                <div className="w-px h-3 bg-slate-800" />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
