/** Shared SVG background — subtle blueprint grid with golden-ratio spacing */

export function GridBackground() {
  return (
    <div className="fixed inset-0 grid-bg pointer-events-none -z-10">
      <svg className="absolute inset-0 w-full h-full opacity-[0.03]" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="phi-grid" width="129.44" height="129.44" patternUnits="userSpaceOnUse">
            <path d="M 129.44 0 L 0 0 0 129.44" fill="none" stroke="#22d3ee" strokeWidth="0.5" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#phi-grid)" />
      </svg>
    </div>
  );
}

/** Decorative corner brackets for technical blueprint feel */
export function CornerBrackets({ color = 'emerald' }: { color?: 'emerald' | 'cyan' | 'slate' }) {
  const c = color === 'emerald' ? 'border-emerald-500/40' : color === 'cyan' ? 'border-cyan-500/40' : 'border-slate-600/40';
  return (
    <>
      <div className={`absolute top-0 left-0 w-3 h-3 border-t border-l ${c}`} />
      <div className={`absolute top-0 right-0 w-3 h-3 border-t border-r ${c}`} />
      <div className={`absolute bottom-0 left-0 w-3 h-3 border-b border-l ${c}`} />
      <div className={`absolute bottom-0 right-0 w-3 h-3 border-b border-r ${c}`} />
    </>
  );
}
