import { motion } from 'framer-motion';
import { FunctionSquare, Wind, RotateCw, Code2, Terminal } from 'lucide-react';
import { CornerBrackets } from '@/components/GridBackground';

const octaveScript = [
  { line: 1, code: 'pkg load symbolic', note: 'Loads the Symbolic Math Toolbox for analytical differentiation and symbolic variables.' },
  { line: 2, code: '', note: '' },
  { line: 3, code: 'syms x y z', note: 'Declares symbolic variables x, y, z — the domain axes for scalar and vector fields.' },
  { line: 4, code: 'f = x^2 + y^2 + z^2;', note: 'Defines a scalar field f(x,y,z) — a paraboloid in 3D space.' },
  { line: 5, code: '', note: '' },
  { line: 6, code: '% --- Gradient: ∇f ---', note: 'The gradient points in the direction of steepest ascent of f.' },
  { line: 7, code: 'grad_f = gradient(f, [x, y, z]);', note: 'Computes ∇f = [∂f/∂x, ∂f/∂y, ∂f/∂z] symbolically.' },
  { line: 8, code: 'disp(grad_f);', note: 'Outputs: [2*x, 2*y, 2*z]' },
  { line: 9, code: '', note: '' },
  { line: 10, code: '% --- Divergence: ∇·F ---', note: 'Divergence measures the net outward flux at a point — source if positive, sink if negative.' },
  { line: 11, code: 'F = [x^2, y^2, z^2];', note: 'Defines vector field F = [F1, F2, F3] as a symbolic vector.' },
  { line: 12, code: 'div_F = divergence(F, [x, y, z]);', note: 'Computes ∇·F = ∂F1/∂x + ∂F2/∂y + ∂F3/∂z.' },
  { line: 13, code: 'disp(div_F);', note: 'Outputs: 2*x + 2*y + 2*z' },
  { line: 14, code: '', note: '' },
  { line: 15, code: '% --- Curl: ∇×F ---', note: 'Curl measures the rotational tendency at a point — nonzero curl implies circulation.' },
  { line: 16, code: 'G = [-y, x, 0];', note: 'Defines a rotational field G = [-y, x, 0] — pure rotation about the z-axis.' },
  { line: 17, code: 'curl_G = curl(G, [x, y, z]);', note: 'Computes ∇×G using the cross-product determinant.' },
  { line: 18, code: 'disp(curl_G);', note: 'Outputs: [0, 0, 2] — rotation about z at angular speed 2.' },
  { line: 19, code: '', note: '' },
  { line: 20, code: '% --- Visualization ---', note: 'Octave meshgrid + quiver for 2D field plotting.' },
  { line: 21, code: '[X, Y] = meshgrid(-5:0.5:5);', note: 'Creates a coordinate grid from -5 to 5 with 0.5 step. X holds x-coords, Y holds y-coords.' },
  { line: 22, code: 'U = -Y;  V = X;', note: 'Computes the vector components for F = [-y, x] at every grid point.' },
  { line: 23, code: 'quiver(X, Y, U, V, 1.5);', note: 'Draws arrow vectors at each (X,Y) with direction (U,V). Scale factor 1.5 normalizes arrow length.' },
  { line: 24, code: 'axis equal; xlabel("x"); ylabel("y");', note: 'Sets equal aspect ratio and labels axes for accurate geometric representation.' },
  { line: 25, code: 'title("Rotational Vector Field: F = [-y, x]");', note: 'Titles the plot — this field has constant curl ∇×F = [0,0,2].' },
];

interface TheoryBlockProps {
  icon: React.ReactNode;
  title: string;
  formula: string;
  description: string;
  detail: string;
  accent: 'emerald' | 'cyan';
}

function TheoryBlock({ icon, title, formula, description, detail, accent }: TheoryBlockProps) {
  const accentColor = accent === 'emerald' ? 'text-emerald-400' : 'text-cyan-400';
  const accentBorder = accent === 'emerald' ? 'border-emerald-500/20' : 'border-cyan-500/20';
  const accentGlow = accent === 'emerald' ? 'glow-emerald' : 'glow-cyan';

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
      className={`relative glass border ${accentBorder} ${accentGlow} p-6 rounded-sm`}
    >
      <CornerBrackets color={accent} />
      <div className="flex items-start gap-4 mb-4">
        <div className={`shrink-0 ${accentColor}`}>{icon}</div>
        <div>
          <h3 className={`font-mono-display text-xs uppercase tracking-[0.2em] ${accentColor}`}>{title}</h3>
          <p className="text-sm text-slate-400 mt-1">{description}</p>
        </div>
      </div>
      <div className={`font-mono-display text-lg ${accentColor} text-glow-${accent} mb-3`}>
        {formula}
      </div>
      <p className="text-sm text-slate-400 leading-relaxed">{detail}</p>
    </motion.div>
  );
}

export function ManualView() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="space-y-2"
      >
        <div className="flex items-center gap-2 text-emerald-400 font-mono-display text-xs uppercase tracking-[0.3em]">
          <Terminal className="w-3.5 h-3.5" />
          <span>Lab Manual / Vector Calculus</span>
        </div>
        <h1 className="text-3xl font-semibold text-slate-100 tracking-tight">
          Vector Field Theory <span className="text-slate-600">—</span> <span className="text-emerald-400">GNU Octave</span> Implementation
        </h1>
        <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
          A structured breakdown of the three fundamental differential operators in vector calculus,
          with corresponding GNU Octave symbolic computation scripts and line-by-line commentary.
        </p>
      </motion.div>

      {/* Theory blocks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <TheoryBlock
          icon={<FunctionSquare className="w-5 h-5" />}
          title="Gradient Field"
          formula="∇f = [∂f/∂x, ∂f/∂y, ∂f/∂z]"
          description="Steepest ascent of a scalar field"
          detail="The gradient transforms a scalar field f(x,y,z) into a vector field. Each component is the partial derivative along that axis. It always points in the direction of maximum increase."
          accent="emerald"
        />
        <TheoryBlock
          icon={<Wind className="w-5 h-5" />}
          title="Divergence Solver"
          formula="∇·F = ∂F₁/∂x + ∂F₂/∂y + ∂F₃/∂z"
          description="Net outward flux density"
          detail="Divergence measures how much a vector field spreads outward from a point. Positive divergence indicates a source; negative indicates a sink. Zero divergence means the field is incompressible."
          accent="cyan"
        />
        <TheoryBlock
          icon={<RotateCw className="w-5 h-5" />}
          title="Curl Rotational Axis"
          formula="∇×F = |i  j  k; ∂x ∂y ∂z; F₁ F₂ F₃|"
          description="Rotational circulation density"
          detail="Curl measures the rotational tendency of a vector field at each point. A nonzero curl indicates circulation. The direction of the curl vector gives the axis of rotation via the right-hand rule."
          accent="emerald"
        />
      </div>

      {/* Octave script with line-by-line explanations */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
        className="glass-dark border border-slate-800 rounded-sm overflow-hidden"
      >
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Code2 className="w-4 h-4 text-emerald-400" />
            <span className="font-mono-display text-xs uppercase tracking-[0.2em] text-slate-300">
              vector_field_lab.m
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-700" />
            <div className="w-2.5 h-2.5 rounded-full bg-slate-700" />
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/60" />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_1fr] divide-y lg:divide-y-0 lg:divide-x divide-slate-800">
          {/* Code panel */}
          <div className="bg-[#020617] overflow-x-auto">
            <pre className="font-mono-display text-[13px] leading-[1.7] p-5">
              {octaveScript.map((row) => (
                <div key={row.line} className="flex hover:bg-emerald-500/[0.03] transition-colors duration-100">
                  <span className="select-none text-slate-700 w-10 text-right pr-4 shrink-0">{row.line}</span>
                  <code className={row.code.startsWith('%') ? 'text-slate-500 italic' : 'text-slate-200'}>
                    {row.code || '\u00A0'}
                  </code>
                </div>
              ))}
            </pre>
          </div>

          {/* Explanation panel */}
          <div className="bg-slate-950/50 p-5 space-y-0 max-h-[600px] overflow-y-auto">
            {octaveScript.filter((r) => r.note).map((row) => (
              <div key={row.line} className="flex gap-3 py-1.5 border-b border-slate-800/50 last:border-0">
                <span className="font-mono-display text-xs text-emerald-500/50 w-8 shrink-0 pt-0.5">L{row.line}</span>
                <p className="text-[13px] text-slate-400 leading-relaxed">{row.note}</p>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Concept summary */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-4"
      >
        {[
          { term: 'meshgrid', desc: 'Generates coordinate matrices X, Y from 1D ranges. Every (X[i,j], Y[i,j]) pair is a sample point in 2D space.' },
          { term: 'quiver', desc: 'Plots 2D velocity vectors as arrows at each grid point. Arrow direction comes from (U, V); length is scaled for visibility.' },
          { term: 'symbolic', desc: 'Octave package enabling exact symbolic math: derivatives, integrals, and algebraic manipulation without floating-point rounding.' },
        ].map((item) => (
          <div key={item.term} className="glass border border-slate-800 p-4 rounded-sm">
            <code className="font-mono-display text-sm text-cyan-400 text-glow-cyan">{item.term}</code>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">{item.desc}</p>
          </div>
        ))}
      </motion.div>
    </div>
  );
}
